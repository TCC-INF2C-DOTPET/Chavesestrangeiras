package br.itb.projeto.dotpet.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adotante;
import br.itb.projeto.dotpet.service.AdotanteService;

@Controller
@RequestMapping("/api/adotante")
public class AdotanteController {

    private final AdotanteService adotanteService;

    public AdotanteController(AdotanteService adotanteService) {
        this.adotanteService = adotanteService;
    }

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("adotante", new Adotante());
        return "Adot-cad-ADM";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Adotante> adicionarAdotante(MultipartFile file, @ModelAttribute Adotante adotante) {
        try {
        	Adotante adotanteSalvo = adotanteService.salvarAdotante(file, adotante);
            return ResponseEntity.ok(adotanteSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
}
