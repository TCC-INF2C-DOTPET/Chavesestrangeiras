package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adotante;
import br.itb.projeto.dotpet.model.repository.AdotanteRepository;



@Service
public class AdotanteService {

    private AdotanteRepository adotanteRepository;

    public AdotanteService(AdotanteRepository adotanteRepository) {
        this.adotanteRepository = adotanteRepository;
    }        

    public List<Adotante> findAll() {
        return adotanteRepository.findAll();
    }

	public Adotante salvarAdotante(MultipartFile file, Adotante adotante) {
		if (adotante.getNome() != null && !adotante.getNome().isEmpty()) {
            
            return adotanteRepository.save(adotante);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}}

