package br.itb.projeto.dotpet.model.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Animal")
public class Catalogotodo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    
	private String tipoAnimal;
    private String nome;
    private String porte;
	private String sexo;

    
    @Column(name = "foto_animal")
    private byte[] foto;
    private String status_animal;
	

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getPorte() {
		return porte;
	}
	public void setPorte(String porte) {
		this.porte = porte;
	}
	
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public byte[] getFoto() {
		return foto;
	}
	public void setFoto(byte[] foto) {
		this.foto = foto;
	}
	public String getStatus_animal() {
		return status_animal;
	}
	public void setStatus_animal(String status_animal) {
		this.status_animal = status_animal;
	}
	
	

	public String getTipoAnimal() {
		return tipoAnimal;
	}
	public void setTipoAnimal(String tipoAnimal) {
		this.tipoAnimal = tipoAnimal;
	}





    // Outros campos e métodos getters/setters
}
