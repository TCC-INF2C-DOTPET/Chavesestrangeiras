package br.itb.projeto.dotpet.model.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Animal")
public class Animal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    
	private String tipoAnimal;
	private String raca;
    private String nome;
    private String cor;
    private String porte;
    private String deficiencia;
    private String sexo;
    @Column(name = "vacinas")
    private String vacinado;
    private String idade;
    private String dt_registro;
    private String castrado;
    private String descricao;
    
    @Column(name = "foto_animal")
    private byte[] foto;
    private String status_animal;
	

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getRaca() {
		return raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getPorte() {
		return porte;
	}
	public void setPorte(String porte) {
		this.porte = porte;
	}
	public String getDeficiencia() {
		return deficiencia;
	}
	public void setDeficiencia(String deficiencia) {
		this.deficiencia = deficiencia;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getVacinado() {
		return vacinado;
	}
	public void setVacinado(String vacinado) {
		this.vacinado = vacinado;
	}
	
	
	public String getIdade() {
		return idade;
	}
	public void setIdade(String idade) {
		this.idade = idade;
	}
	public String getDt_registro() {
		return dt_registro;
	}
	public void setDt_registro(String dt_registro) {
		this.dt_registro = dt_registro;
	}
	public String getCastrado() {
		return castrado;
	}
	public void setCastrado(String castrado) {
		this.castrado = castrado;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public byte[] getFoto() {
		return foto;
	}
	public void setFoto(byte[] foto) {
		this.foto = foto;
	}
	public String getStatus_animal() {
		return status_animal;
	}
	public void setStatus_animal(String status_animal) {
		this.status_animal = status_animal;
	}
	
	

	public String getTipoAnimal() {
		return tipoAnimal;
	}
	public void setTipoAnimal(String tipoAnimal) {
		this.tipoAnimal = tipoAnimal;
	}





    // Outros campos e métodos getters/setters
}
