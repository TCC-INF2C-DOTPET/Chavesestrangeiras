package br.itb.projeto.dotpet.service;


import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Animal;
import br.itb.projeto.dotpet.model.repository.AnimalRepository;



@Service
public class AnimalService {

	private AnimalRepository animalRepository;
	
	
	public AnimalService(AnimalRepository animalRepository) {
		super();
		this.animalRepository = animalRepository;
	}


	public Animal salvarAnimal(MultipartFile file, Animal animal) {
		
		if (file != null && file.getSize() > 0) {
			try {
				animal.setFoto(file.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			animal.setFoto(null);
		}
		animal.setStatus_animal("Ativo");
		return animalRepository.save(animal);
	}


	public List<Animal> findAll() {
		return animalRepository.findAll();
	}


	public Animal findById(long id) {
		return animalRepository.findById(id).get();
	}


	
}