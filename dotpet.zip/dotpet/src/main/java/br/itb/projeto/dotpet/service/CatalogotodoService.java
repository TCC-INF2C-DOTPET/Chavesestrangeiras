package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Animal;
import br.itb.projeto.dotpet.model.entity.Catalogotodo;
import br.itb.projeto.dotpet.model.repository.CatalogotodoRepository;



@Service
public class CatalogotodoService {

    private CatalogotodoRepository catalogotodoRepository;

    public CatalogotodoService(CatalogotodoRepository catalogotodoRepository) {
        this.catalogotodoRepository = catalogotodoRepository;
    }        

    public List<Catalogotodo> findAll() {
        return catalogotodoRepository.findAll();
    }

	public Catalogotodo salvarCatalogotodo(MultipartFile file, Catalogotodo catalogotodo) {
		if (catalogotodo.getNome() != null && !catalogotodo.getNome().isEmpty()) {
            
            return catalogotodoRepository.save(catalogotodo);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}



}

