package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adocao;
import br.itb.projeto.dotpet.model.repository.AdocaoRepository;



@Service
public class AdocaoService {

    private AdocaoRepository adocaoRepository;

    public AdocaoService(AdocaoRepository adocaoRepository) {
        this.adocaoRepository = adocaoRepository;
    }        

    public List<Adocao> findAll() {
        return adocaoRepository.findAll();
    }

	public Adocao salvarAdocao(MultipartFile file, Adocao adocao) {
		if (adocao.getObservacoes() != null && !adocao.getObservacoes().isEmpty()) {
            
            return adocaoRepository.save(adocao);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}}

