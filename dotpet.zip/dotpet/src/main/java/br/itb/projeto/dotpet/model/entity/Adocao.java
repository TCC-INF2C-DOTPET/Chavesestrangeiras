package br.itb.projeto.dotpet.model.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Adocao")


		public class Adocao{
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private long id;
	    
	    private String adotante_id;
		private String funcionario_Id;
	    private String animal_id;
		private String data_adocao;
	    private String observacoes;
	    
	    public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getAdotante_id() {
			return adotante_id;
		}
		public void setAdotante_id(String adotante_id) {
			this.adotante_id = adotante_id;
		}
		public String getFuncionario_Id() {
			return funcionario_Id;
		}
		public void setFuncionario_Id(String funcionario_Id) {
			this.funcionario_Id = funcionario_Id;
		}
		
		public String getAnimal_id() {
			return animal_id;
		}
		public void setAnimal_id(String animal_id) {
			this.animal_id = animal_id;
		}
		
		 public String getData_adocao() {
				return data_adocao;
			}
			public void setData_adocao(String data_adocao) {
				this.data_adocao = data_adocao;
			}
			public String getObservacoes() {
				return observacoes;
			}
			public void setObservacoes(String observacoes) {
				this.observacoes = observacoes;
			}
		

}